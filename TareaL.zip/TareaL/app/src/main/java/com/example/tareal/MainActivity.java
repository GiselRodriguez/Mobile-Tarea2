package com.example.tareal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText etu, etp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        etu = (EditText)findViewById(R.id.txt_usuario);
        etp = (EditText)findViewById(R.id.txt_password);
    }




    //Método para el botón
    public void Registrar(View view){


        String usuario = etu.getText().toString();
        String passward = etp.getText().toString();

        if(usuario.length() == 0){
            Toast.makeText(this, "Debe ingresar un nombre", Toast.LENGTH_SHORT).show();

        }
        if(passward.length() == 0){
            Toast.makeText(this, "Debe ingresar una password", Toast.LENGTH_LONG).show();
        }
        if(usuario.length() != 0 && passward.length() != 0){
            Toast.makeText(this, "Registro en proceso...", Toast.LENGTH_LONG).show();
            Intent i = new Intent(this, Main2Activity.class);
            i.putExtra("dato", etu.getText().toString());
            startActivity(i);
        }


    }
}
